import React from 'react';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getUser from '@wasp/queries/getUser';
import updateUser from '@wasp/actions/updateUser';

export function UserProfilePage() {
  const { data: user, isLoading, error } = useQuery(getUser);
  const updateUserFn = useAction(updateUser);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateUser = () => {
    // Implement the logic to update user profile
  };

  return (
    <div className='p-4'>
      <h1>User Profile Page</h1>
      <div className='mb-4'>
        <label className='block mb-2'>Username:</label>
        <input
          type='text'
          value={user.username}
          className='border py-2 px-4 rounded'
          readOnly
        />
      </div>
      <div className='mb-4'>
        <label className='block mb-2'>BMI:</label>
        <input
          type='text'
          value={user.bmi}
          className='border py-2 px-4 rounded'
          readOnly
        />
      </div>
      {/* Add more fields for displaying user profile information */}
      <button
        onClick={handleUpdateUser}
        className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
      >
        Update Profile
      </button>
    </div>
  );
}