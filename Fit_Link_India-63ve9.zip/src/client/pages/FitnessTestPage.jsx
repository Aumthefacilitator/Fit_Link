import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { FitnessTestForm } from '@client/components/FitnessTestForm.jsx';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getFitnessTest from '@wasp/queries/getFitnessTest';
import updateFitnessTest from '@wasp/actions/updateFitnessTest';

export function FitnessTestPage() {
  const { fitnessTestId } = useParams();
  const { data: fitnessTest, isLoading, error } = useQuery(getFitnessTest, { id: fitnessTestId });
  const updateFitnessTestFn = useAction(updateFitnessTest);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateFitnessTest = (updatedData) => {
    updateFitnessTestFn({ id: fitnessTestId, ...updatedData });
  };

  return (
    <div>
      <h1>Fitness Test</h1>
      <FitnessTestForm fitnessTest={fitnessTest} onUpdate={handleUpdateFitnessTest} />
    </div>
  );
}