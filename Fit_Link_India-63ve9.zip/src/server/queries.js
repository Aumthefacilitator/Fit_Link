import HttpError from '@wasp/core/HttpError.js'

export const getUser = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) }

  const user = await context.entities.User.findUnique({
    where: { id: arg.id }
  });

  return user;
}

export const getUsers = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.User.findMany();
}

export const getFitnessTest = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) }

  const fitnessTest = await context.entities.FitnessTest.findUnique({
    where: { id: arg.id },
  });

  return fitnessTest;
}

export const getFitnessTests = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.FitnessTest.findMany();
}