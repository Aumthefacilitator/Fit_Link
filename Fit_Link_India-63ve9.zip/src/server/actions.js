import HttpError from '@wasp/core/HttpError.js'

export const createUser = async (args, context) => {
  const { username, password, bmi, height, weight, age, gender, activityLevel, bmr, idealWeight, pace, leanBodyMass, healthyWeightRange, macro, carbohydrateIntake, proteinIntake, fatIntake, tdee, gfr, bodyType, bodySurfaceArea, bac } = args;

  if (!context.user) {
    throw new HttpError(401);
  }

  const newUser = await context.entities.User.create({
    data: {
      username,
      password,
      bmi,
      height,
      weight,
      age,
      gender,
      activityLevel,
      bmr,
      idealWeight,
      pace,
      leanBodyMass,
      healthyWeightRange,
      macro,
      carbohydrateIntake,
      proteinIntake,
      fatIntake,
      tdee,
      gfr,
      bodyType,
      bodySurfaceArea,
      bac
    }
  });

  return newUser;
}

export const updateUser = async (args, context) => {
  const { id, data } = args;

  if (!context.user) { throw new HttpError(401) };

  const user = await context.entities.User.findUnique({
    where: { id }
  });
  if (!user) { throw new HttpError(404) };

  return context.entities.User.update({
    where: { id },
    data
  });
}

export const deleteUser = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const user = await context.entities.User.findUnique({
    where: { id: args.userId }
  });
  if (!user) { return false };

  await context.entities.User.delete({
    where: { id: args.userId }
  });

  return true;
}

export const createFitnessTest = async ({ data }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const createdFitnessTest = await context.entities.FitnessTest.create({
    data: {
      userId: context.user.id,
      vo2max: data.vo2max,
      oneRepMax: data.oneRepMax,
      flexibilityScore: data.flexibilityScore,
      pushUpCount: data.pushUpCount,
      bodyFatPercentage: data.bodyFatPercentage
    }
  });

  return createdFitnessTest;
}

export const updateFitnessTest = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const fitnessTest = await context.entities.FitnessTest.findUnique({
    where: { id: args.id }
  });
  if (fitnessTest.userId !== context.user.id) { throw new HttpError(403) };

  return context.entities.FitnessTest.update({
    where: { id: args.id },
    data: { 
      vo2max: args.vo2max,
      oneRepMax: args.oneRepMax,
      flexibilityScore: args.flexibilityScore,
      pushUpCount: args.pushUpCount,
      bodyFatPercentage: args.bodyFatPercentage
    }
  });
}

export const deleteFitnessTest = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  const fitnessTest = await context.entities.FitnessTest.findUnique({
    where: { id: args.id }
  })

  if (fitnessTest.userId !== context.user.id) { throw new HttpError(403) }

  await context.entities.FitnessTest.delete({
    where: { id: args.id }
  })

  return true
}